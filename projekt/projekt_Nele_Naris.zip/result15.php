<?php
/*
 * Nele Naris, 29. mai 2016, PHP kursus 2016 kevad
 * 
 * See fail kuvab tulemuse.
 * 
*/
include 'questions.php';

echo "<html><title>Result</title><body bgcolor='#4371F7'><center>";

      if (isset($_POST["answer"])) 
          {
                if (isset($_POST["question15"])) 
                    {
                        $answer = $_POST["question15"];
                        if ($answer == "ans2") 
                            {
                                echo '<b>Correct answer!<br>
                               
                                You win '.$question15[9].' dollars!</b><br><br>
                                <img src="million.png" alt="Icon" width="384" height="285"><br> 
                                This is the end.<br><br>
                                <form method="get" action="question1.php">
                                <button type="submit">Start Your new game here!</button>
                                </form>';
                            } 
           
                        else 
                            {
                                echo '<b>Wrong answer! :(</b><br>
                                <form method="post" action="index.html">
                                <input type="submit" name="to_start" value="Start Your game from the beginning here!">
                                </form>';
                            }    
                    }
        else
            {
                echo 'Please choose Your answer.
                    <form method="post" action="question15.php">
                    <input type="submit" name="question" value="Go back!">
                    </form>';
            }
        }
echo "</center></body></html>";
?>

