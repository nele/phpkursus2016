<?php
/*
 * Nele Naris, 29. mai 2016, PHP kursus 2016 kevad
 * 
 * See fail kuvab tulemuse.
 * 
*/
include 'questions.php';

echo "<html><title>Result</title><body bgcolor='#4371F7'><center>";

      if (isset($_POST["answer"])) 
          {
                if (isset($_POST["question7"])) 
                    {
                        $answer = $_POST["question7"];
                        if ($answer == "ans1") 
                            {
                                echo '<b>Correct answer!<br>
                                <form method="post" action="question8.php">
                                You win '.$question7[9].' dollars!</b><br><br>
                                <input type="submit" name="answer" value="Continue with the game">
                                </form>';
                            } 
           
                        else 
                            {
                                echo '<b>Wrong answer! :(</b><br>
                                <form method="post" action="index.html">
                                <input type="submit" name="to_start" value="Start Your game from the beginning here!">
                                </form>';
                            }    
                    }
        else
            {
                echo 'Please choose Your answer.
                    <form method="post" action="question7.php">
                    <input type="submit" name="question" value="Go back!">
                    </form>';
            }
        }
echo "</center></body></html>";
?>

