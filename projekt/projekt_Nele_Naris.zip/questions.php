<?php  
/*
 * Nele Naris, 29. mai 2016, PHP kursus 2016 kevad
 * 
 * See fail sisaldab 15 küsimusega infot.
 * 
*/

#100

$question1=array("Who are television's Rachel, Monica, Chandler, Ross, Phoebe, and Joey?","The Waltons","Friends", "Neighbours","The Flinstones","0","1","0","0","100","1");


#200

$question2=array("What is the surname of Tommy, the fashion designer with a distinctive blue, white and red logo?","Lauren","Boss", "Armani","Hilfiger","0","0","0","1","200","2");


#300

$question3=array("What is the Italian word for a square or marketplace?","Piazza","Pizza", "Pozzo","Plaza","1","0","0","0","300","3");

#500
$question4=array("What would two people be doing if they were trying a pas de deux?","Ballet dancing","Singing","Trampolining","Duelling","1","0","0","0","500","4");


#1000
$question5=array("Which musical includes the song Climb Every Mountain?","My Fair Lady","The Sound of Music","Oklahoma!","South Pacific","0","1","0","0","1000","5");


#2000

$question6=array("Which building do the Beefeaters guard?","Tower of London","Buckingham Palace","Houses of Parliament","Windsor Castle","1","0","0","0","2000","6");


#4000

$question7=array("What does the I stand for in PIN number?","Identification","Index","Internal","International","1","0","0","0","4000","7");

#8000

$question8=array("How many teeth does an adult have in full set?","24","26","30","32","0","0","0","1","8000","8");


#16 000

$question9=array("What do the French call the English Channel?","Le Channel Francais","La Manche","Le Pas de Calais","La Mer Anglaise","0","1","0","0","16000","9");


#32 000

$question10=array("What does the Statue of Liberty hold in its right hand?","Scales","Torch","Sword","Book","0","1","0","0","32000","10");

#64 000

$question11=array("Which month of the year comes sixth alphabetically?","January","March","June","July","0","0","0","1","64000","11");

#125 000

$question12=array("Which mammal's intelligence is said to be second only to humans?","Gorilla","Baboon","Orang-utan","Chimpanzee","0","0","0","1","125000","12");

#250 000

$question13=array("What would a doctor measure with a sphygmanometer?","Blood pressure","Skin elasticity","Blood sugar level","Lung capacity","1","0","0","0","25000","13");


#500 000

$question14=array("What is the offspring of a lion and a tigress called?","Liger","Tigon","Tigelon","Ligron","1","0","0","0","500000","14");


#1 000 000

$question15=array("From which central point are distances measured in miles from London?","Leicester Square","Charing Cross","Piccadilly Circus","Trafalgar Square","0","1","0","0","1000000","15");


?>