<?php
/*
 * Nele Naris, 30. mai 2016, PHP kursus 2016 kevad
 * 
 * See fail kuvab infot reeglite kohta.
 * 
*/
echo '
<html>
<title>Rules of Play</title>
<body bgcolor="#4371F7">
<center>
<h1>Who Wants to be a Millionaire?</h1>
<h2>Rules of Play</h2>
<br>
Choose your answer from the four given answers.<br><br>
Push the button Answer.<br><br>
When you give the correct answer you can continue to the next question.<br><br>
Choosing the wrong answer, you will be asked to start from the beginning.<br><br>
All together there is 15 questions, and you have to answer all of them to win million dollars.<br><br>';

#Edasine kuvab nupu, millega saab peale reeglite lugemist mängu alustada.

echo '
<form method="get" action="question1.php">
    <button type="submit">Start Your game here!</button>
</form>
</center>
</body>
</html>
';

?>