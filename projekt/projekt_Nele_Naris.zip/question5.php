<?php
include 'questions.php';
/*
 * Nele Naris, 29. mai 2016, PHP kursus 2016 kevad
 * 
 * See fail kuvab küsimuse.
 * 
*/
echo "<html>
    <title>Question</title>
    <header></header>
    <body bgcolor='#4371F7'>
    <center>
    <H1>Who wants to be a millionaire?</H1><br>
    <b>Question number ".$question5[10]."<br><br> 
    Worth ".$question5[9]." dollars</b><br><br>"; 
    
echo $question5[0];

echo ' <br><br>

<form method="post" action="result5.php">

<table border="1" style="width:50%">
    <tr>
        <td><input type="radio" name="question5" value=ans1>'.$question5[1].'</td>
        <td><input type="radio" name="question5" value="ans2">'.$question5[2].'</td>
    </tr>
    <tr>
        <td><input type="radio" name="question5" value="ans3">'.$question5[3].'</td>
        <td><input type="radio" name="question5" value="ans4">'.$question5[4].'</td>
    </tr>
</table>

<input type="submit" name="answer" value="Answer">
</form>

</center>
</body>
</html>
';


?>