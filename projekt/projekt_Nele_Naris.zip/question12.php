<?php
include 'questions.php';
/*
 * Nele Naris, 29. mai 2016, PHP kursus 2016 kevad
 * 
 * See fail kuvab küsimuse.
 * 
*/
echo "<html>
    <title>Question</title>
    <header></header>
    <body bgcolor='#4371F7'>
    <center>
    <H1>Who wants to be a millionaire?</H1><br>
    <b>Question number ".$question12[10]."<br><br> 
    Worth ".$question12[9]." dollars</b><br><br>"; 
    
echo $question12[0];

echo ' <br><br>

<form method="post" action="result12.php">

<table border="1" style="width:50%">
    <tr>
        <td><input type="radio" name="question12" value=ans1>'.$question12[1].'</td>
        <td><input type="radio" name="question12" value="ans2">'.$question12[2].'</td>
    </tr>
    <tr>
        <td><input type="radio" name="question12" value="ans3">'.$question12[3].'</td>
        <td><input type="radio" name="question12" value="ans4">'.$question12[4].'</td>
    </tr>
</table>

<input type="submit" name="answer" value="Answer">
</form>

</center>
</body>
</html>
';


?>