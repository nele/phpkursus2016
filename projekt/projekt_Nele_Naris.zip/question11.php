<?php
include 'questions.php';
/*
 * Nele Naris, 29. mai 2016, PHP kursus 2016 kevad
 * 
 * See fail kuvab küsimuse.
 * 
*/
echo "<html>
    <title>Question</title>
    <header></header>
    <body bgcolor='#4371F7'>
    <center>
    <H1>Who wants to be a millionaire?</H1><br>
    <b>Question number ".$question11[10]."<br><br> 
    Worth ".$question11[9]." dollars</b><br><br>"; 
    
echo $question11[0];

echo ' <br><br>

<form method="post" action="result11.php">

<table border="1" style="width:50%">
    <tr>
        <td><input type="radio" name="question11" value=ans1>'.$question11[1].'</td>
        <td><input type="radio" name="question11" value="ans2">'.$question11[2].'</td>
    </tr>
    <tr>
        <td><input type="radio" name="question11" value="ans3">'.$question11[3].'</td>
        <td><input type="radio" name="question11" value="ans4">'.$question11[4].'</td>
    </tr>
</table>

<input type="submit" name="answer" value="Answer">
</form>

</center>
</body>
</html>
';


?>